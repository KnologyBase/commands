
<?php
$usrEmail = 'victor@anubavam.com';
$pwd	  = '';

$srcFilePath = '192.pdf';

    require 'DropboxUploader.php';

    try {
        // Upload
        $uploader = new DropboxUploader($usrEmail, $pwd);
        $uploader->upload($srcFilePath);

        echo 'File successfully uploaded to your Dropbox!';
    } catch (Exception $e) {
        // Handle Upload Exceptions
        $label = ($e->getCode() & $uploader::FLAG_DROPBOX_GENERIC) ? 'DropboxUploader' : 'Exception';
        $error = sprintf("[%s] #%d %s", $label, $e->getCode(), $e->getMessage());

        echo '<span style="color: red">Error: ' . htmlspecialchars($error) . '</span>';
    }

?>

